/*
 * ngx_http_navi_module_setup.c
 *
 *  Created on: 2013-9-23
 *      Author: yanguotao@youku.com
 */

ngx_module_t  ngx_http_navi_module;
static navi_module_mgr_t* navi_module_mgr = NULL;
ngx_event_t* ev_check_time = NULL;
ngx_cycle_t* pcycle = NULL;

static ngx_int_t ngx_http_navi_init_worker(ngx_cycle_t *cycle) 
{
    ngx_http_navi_main_conf_t* mcf = ngx_http_cycle_get_module_main_conf(cycle, ngx_http_navi_module);
    if (navi_module_mgr == NULL){
        if (mcf->navi_directory.len == 0){
            navi_module_mgr = navi_mgr_init(NULL);
        }
        else{
            navi_module_mgr = navi_mgr_init((const char *)(mcf->navi_directory.data));
        }
    }

    if (navi_module_mgr == NULL){
        return NGX_ERROR;
    }

    if (mcf->check_interval == NGX_CONF_UNSET){
        mcf->check_interval  = NGX_HTTP_NAVI_DEFAULT_CHECK_INTERVAL;
    }
    if (ev_check_time == NULL && mcf->check_interval > 0){
        ev_check_time = ngx_pcalloc(cycle->pool,sizeof(ngx_event_t));
        ev_check_time->handler = ngx_http_navi_module_check;
        ev_check_time->data = (void *)(mcf->check_interval);
        ngx_add_timer(ev_check_time, (mcf->check_interval)*1000);
    }

    pcycle = cycle;
    
    return NGX_OK;
}

static void ngx_http_navi_exit_worker(ngx_cycle_t *cycle) 
{
    if (navi_module_mgr != NULL){
        navi_mgr_free(navi_module_mgr);
        navi_module_mgr = NULL;
    }
}

static char* ngx_http_navi_setup_handler(ngx_conf_t *cf, void * conf, ngx_int_t (*handler)(ngx_http_request_t *))
{
    ngx_http_core_loc_conf_t* clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = handler;
    clcf->if_modified_since = NGX_HTTP_IMS_OFF;
    return NGX_CONF_OK;
}

static char* ngx_http_navi_init(ngx_conf_t *cf, ngx_command_t *cmd, void *conf) 
{
    return ngx_http_navi_setup_handler(cf,conf,&ngx_http_navi_init_handler);
}

static void* ngx_http_navi_create_main_conf(ngx_conf_t *cf) 
{
    ngx_http_navi_main_conf_t* mcf = ngx_pcalloc(cf->pool, sizeof(*mcf));
    if(mcf == NULL) {
        return NGX_CONF_ERROR;
    }
    mcf->check_interval = NGX_CONF_UNSET;
    return mcf;
}

static ngx_command_t  ngx_http_navi_commands[] = {
    { ngx_string("navi_check_interval"),
      NGX_HTTP_MAIN_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_num_slot,
      NGX_HTTP_MAIN_CONF_OFFSET,
      offsetof(ngx_http_navi_main_conf_t, check_interval),
      NULL },
    { ngx_string("navi_directory"),
      NGX_HTTP_MAIN_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_MAIN_CONF_OFFSET,
      offsetof(ngx_http_navi_main_conf_t, navi_directory),
      NULL },
    { ngx_string("navi_init"),
      NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_navi_init,
      NGX_HTTP_LOC_CONF_OFFSET,
      0,
      NULL },
    ngx_null_command
};

static ngx_http_module_t  ngx_http_navi_module_ctx = {
    NULL,                                     /* preconfiguration */
    ngx_http_navi_filter_init,     /* postconfiguration */
    ngx_http_navi_create_main_conf,    /* create main configuration */
    NULL,        /* init main configuration */
    NULL,                                     /* create server configuration */
    NULL,                                     /* merge server configuration */
    NULL,                                     /* create location configuration */
    NULL,                                     /* merge location configuration */
};

ngx_module_t  ngx_http_navi_module = {
    NGX_MODULE_V1,
    &ngx_http_navi_module_ctx,             /* module context */
    ngx_http_navi_commands,                /* module directives */
    NGX_HTTP_MODULE,                       /* module type */
    NULL,                                  /* init master */
    NULL,                                 /* init module */
    ngx_http_navi_init_worker,             /* init process */
    NULL,                                  /* init thread */
    NULL,                                  /* exit thread */
    ngx_http_navi_exit_worker,             /* exit process */
    NULL,             /* exit master */
    NGX_MODULE_V1_PADDING
};


