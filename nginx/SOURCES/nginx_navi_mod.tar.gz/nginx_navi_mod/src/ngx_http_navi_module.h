/*
 * ngx_http_navi_module.h
 *
 *  Created on: 2013-9-23
 *      Author: yanguotao@youku.com
 */

#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_channel.h>


#define NGX_HTTP_NAVI_DEFAULT_CHECK_INTERVAL 5

#define NGX_HTTP_BUF_ALLOC_SIZE(buf)                                          \
    (sizeof(*buf) +                                                           \
	 (((buf)->temporary || (buf)->memory) ? ngx_buf_size(buf) : 0) +          \
	 (((buf)->file!=NULL) ? (sizeof(*(buf)->file) + (buf)->file->name.len + 1) : 0))

ngx_int_t   ngx_http_navi_worker_processes;

typedef struct {
    navi_request_t *navi_req;
    void *data;
    ngx_int_t  processed;
} ngx_http_navi_ctx_t;

typedef struct ngx_http_navi_header_val_s ngx_http_navi_header_val_t;
typedef ngx_int_t (*ngx_http_navi_set_header_pt)(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value);

struct ngx_http_navi_header_val_s {
    ngx_uint_t                              hash;
    ngx_str_t                               key;
    ngx_http_navi_set_header_pt              handler;
    ngx_uint_t                              offset;
};

typedef struct {
    ngx_str_t                               name;
    ngx_uint_t                              offset;
    ngx_http_navi_set_header_pt              handler;
} ngx_http_navi_set_header_t;

typedef struct {
	ngx_int_t   check_interval;
	ngx_str_t  navi_directory;
} ngx_http_navi_main_conf_t;

static ngx_http_output_header_filter_pt next_header_filter;
static ngx_http_output_body_filter_pt next_body_filter;
static ngx_int_t ngx_http_navi_header_filter(ngx_http_request_t *r);
static ngx_int_t ngx_http_navi_body_filter(ngx_http_request_t * r, ngx_chain_t * in);
static ngx_int_t ngx_http_navi_filter_init(ngx_conf_t *cf);
static ngx_int_t ngx_http_navi_sr_end_handler(ngx_http_request_t *r, void *data, ngx_int_t rc);
static ngx_int_t ngx_http_navi_main_end_handler_common(ngx_http_request_t * r);
static void ngx_http_navi_main_end_handler(ngx_http_request_t* r) ;
static ngx_int_t ngx_http_navi_add_subrequest(ngx_http_request_t *r, navi_request_t *sub, ngx_uint_t flags);
static void  ngx_http_navi_timer_process();
static void ngx_http_navi_module_check(ngx_event_t *ev) ;

static  ngx_int_t ngx_http_navi_add_header_in(ngx_http_request_t* r, const ngx_str_t* key, const ngx_str_t* value);
static ngx_int_t ngx_http_navi_add_header_out(ngx_http_request_t *r, const ngx_str_t * key, const ngx_str_t* value);
static ngx_int_t ngx_http_navi_respond_header(ngx_http_request_t *r, ngx_str_t* content_type,
        ngx_int_t  content_len, ngx_int_t  status_code, const ngx_str_t *status_line);

static ngx_int_t  ngx_http_navi_init_handler(ngx_http_request_t* r);

static ngx_int_t  ngx_http_navi_process_request(ngx_http_request_t* r);

static navi_request_t * ngx_http_navi_build_request(ngx_http_request_t* r);
static void ngx_http_navi_body_handler(ngx_http_request_t * r);

const ngx_str_t NGX_HTTP_NAVI_HEADER_ALLOW = ngx_string("Allow");

const ngx_str_t NGX_HTTP_NAVI_ALLOW_METHOD = ngx_string("Only allow GET,POST");

