/*
 * ngx_http_navi_module.c
 *
 *  Created on: 2013-9-23
 *      Author: yanguotao@youku.com
 */

#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <nginx.h>

#include <cnavidriver/navi_module_driver.h>
#include <cnavidriver/navi_module_mgr.h>
#include <cnavidriver/navi_request_driver.h>
 
#include <ngx_http_navi_module.h>
#include <ngx_http_navi_module_setup.c>


/*��post�����buf���õ�cnavi*/
static ngx_int_t ngx_http_navi_process_postbuf(navi_request_t *navi_req, ngx_http_request_t* r)
{
    ngx_chain_t         *cl;
    ngx_buf_t* postbuf = NULL;
    ngx_int_t rc;
    if (r->method != NGX_HTTP_POST){
        return NGX_ERROR;
    }

    if (r->request_body == NULL || r->request_body->bufs == NULL){
        return NGX_ERROR;
    }
    for (cl = r->request_body->bufs; cl; cl = cl->next) {
        postbuf =  cl->buf;  
        ngx_int_t postlen = ngx_buf_size(postbuf);
        if (postlen > 0){            
            if(ngx_buf_in_memory(postbuf)) {
                rc = navi_http_request_append_post(navi_req, postbuf->pos, postlen);
                if (rc != NGX_OK){
                    return rc;		
                }
            } else if ((NULL != r->request_body->temp_file) 
            		&& (NGX_INVALID_FILE != r->request_body->temp_file->file.fd)){
            	 u_char* post = ngx_palloc(r->pool, postlen+1);	
                ssize_t nread = ngx_read_file(&(r->request_body->temp_file->file), post, postlen, 0);
                post[nread] = '\0';
                return navi_http_request_append_post(navi_req, post, postlen);
            } 
        }
    }

    return NGX_OK;
}

/*��ȡ��navi req��Ӧ��ngx_http_request*/
static ngx_http_request_t * ngx_http_navi_get_root_req(navi_request_t *req)
{
    if (req == NULL){
        return NULL;
    }
    navi_request_t *root = navi_request_get_root(req);
    return (ngx_http_request_t*)navi_request_get_driver_peer(root);	
}

/*post�������body֮��Ļص�*/
static void ngx_http_navi_body_handler(ngx_http_request_t* r)
{
    if(r->request_body == NULL || r->request_body->bufs == NULL 
		|| r->headers_in.content_length_n <= 0) {
        ngx_http_finalize_request(r, NGX_HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    /*buf�ڵ����ڴ���,��Ϊ������ r->request_body_in_single_buf = 1; */	
    if(r->request_body->bufs->buf == NULL && r->request_body->bufs->next == NULL) {
        ngx_log_error(NGX_LOG_ERR, (r)->connection->log, 0, "Nginx Navi Mod ERROR, unexpected post request body buffer location.");
        ngx_http_finalize_request(r, NGX_HTTP_INTERNAL_SERVER_ERROR);
        return;
    }
    
    ngx_http_navi_process_request(r);
}

/*װ��filter,��post configuraton��ʱ�򱻵���
* ��Ҫ���ڽٳ����������Ӧ
*/
static ngx_int_t ngx_http_navi_filter_init(ngx_conf_t *cf)
{
    next_header_filter = ngx_http_top_header_filter;
    ngx_http_top_header_filter = ngx_http_navi_header_filter;

    next_body_filter = ngx_http_top_body_filter;
    ngx_http_top_body_filter = ngx_http_navi_body_filter;

    return NGX_OK;
}

/*header filter,���ڱ�ģ���������ǿ����Ӧ�屣�����ڴ���*/
static ngx_int_t ngx_http_navi_header_filter(ngx_http_request_t *r) 
{
    ngx_http_post_subrequest_t      *psr;
    ngx_http_navi_ctx_t              *old_ctx;
    ngx_http_navi_ctx_t              *ctx;
    
    ctx = ngx_http_get_module_ctx(r, ngx_http_navi_module);
    psr = r->post_subrequest;
       	
    if (psr != NULL
    	&& psr->handler == ngx_http_navi_sr_end_handler
    	&& psr->data != NULL)
    {
        old_ctx = psr->data;
    
        if (ctx == NULL) {
            ctx = old_ctx;
            ngx_http_set_ctx(r, ctx, ngx_http_navi_module);
        } else {	
            psr->data = ctx;
        }
    }
    
    //��������������������Header filter
    if (ctx && (ctx->navi_req) !=NULL && (ctx->navi_req)  != navi_request_get_root(ctx->navi_req)) {
        /* ʹ���������Ӧ�����ڴ��� */
        r->filter_need_in_memory = 1;
        r->main->count++;
        return NGX_OK;
    }
    
    return next_header_filter(r);
}

/*�����������Ӧ�忽����navi request����Ӧ��*/
static ngx_int_t ngx_http_navi_copy_chain(navi_request_t *req, ngx_chain_t *in)
{
    ngx_chain_t     *cl;

    for (cl = in; cl; cl = cl->next) {
        if (ngx_buf_in_memory(cl->buf)) {
            if (navi_http_response_append_body(req, cl->buf->pos, cl->buf->last - cl->buf->pos) 
                    != NAVI_OK){
                return NGX_ERROR;
            }
        }
    }

    return NGX_OK;
}

/*���������󣬽���Ӧ�忽����navi request����Ӧ��*/
static ngx_int_t ngx_http_navi_body_filter(ngx_http_request_t *r, ngx_chain_t *in) 
{
    ngx_int_t                        rc;
    ngx_http_navi_ctx_t       *ctx;
    navi_request_t               *req;
    ngx_http_navi_ctx_t       *pr_ctx;
    
    if (in == NULL) {
    	return next_body_filter(r, NULL);
    }
    
    ctx = ngx_http_get_module_ctx(r, ngx_http_navi_module);
    
    if (!ctx ) {
    	return next_body_filter(r, in);
    }

    req = ctx->navi_req;
    if (req == NULL){
        return NGX_ERROR;
    }

    ngx_http_request_t *pr = ngx_http_navi_get_root_req(req);
    if (pr == NULL){
         return NGX_ERROR;
    }

    if (r == pr || r == r->main){
        return next_body_filter(r, in);
    }

    pr_ctx = ngx_http_get_module_ctx(r->parent, ngx_http_navi_module);
    if (pr_ctx == NULL) {
        return NGX_ERROR;
    }
    
    rc = ngx_http_navi_copy_chain(req, in);
    
    for (; in; in = in->next) {
        in->buf->pos = in->buf->last;
        in->buf->file_pos = in->buf->file_last;
    }
    
    return NGX_OK;
}

/*��navi request���õ�post�����������õ�ngx_http_request��*/
static  ngx_int_t  ngx_http_navi_set_post(ngx_http_request_t *r, 
	const u_char *post_content, ngx_int_t post_len)
{
    ngx_http_request_body_t         *body;
    if (post_len <= 0){
        return NGX_ERROR;	
    }
	
    body = ngx_pcalloc(r->pool, sizeof(ngx_http_request_body_t));
    
    if (body == NULL) {
        return NGX_ERROR;
    }

    r->method_name.len = 4;
    r->method_name.data = (u_char *)"POST ";
    r->method = NGX_HTTP_POST;

    ngx_buf_t *b = ngx_create_temp_buf(r->pool, post_len);
    if (b == NULL) {
        return NGX_ERROR;
    }

    b->last = ngx_copy(b->last, post_content, post_len);

    body->bufs = ngx_alloc_chain_link(r->pool);
    if (body->bufs == NULL) {
        return NGX_ERROR;
    }

    body->bufs->buf = b;
    body->bufs->next = NULL;

    body->buf = b;
    r->request_body = body;

    r->headers_in.content_length_n = post_len;

    return NGX_OK;
}

/*��ngx_http_request�������Ϣ���õ�navi request*/
static navi_request_t * ngx_http_navi_build_request(ngx_http_request_t* r)
{
    ngx_int_t rc;
    navi_request_t*navi_req = navi_request_init();
    if (navi_req == NULL){
        return NULL;
    }
    char* uri = ngx_palloc(r->pool,r->uri.len+1);
    ngx_memcpy(uri,r->uri.data,(size_t)r->uri.len);
    uri[r->uri.len] = '\0';
    rc = navi_http_request_set_uri(navi_req, uri,  0);
    if (rc != NAVI_OK){
        navi_request_free(navi_req);
        return NULL;
    }
    navi_request_parse_main_uri(navi_req);

    if(r->args.len > 0){
        char* args = ngx_palloc(r->pool,r->args.len+1);
        ngx_memcpy(args,r->args.data,(size_t)r->args.len);
        args[r->args.len] = '\0';
        rc = navi_http_request_set_args_raw(navi_req, args);
        if (rc != NAVI_OK){
            navi_request_free(navi_req);
            return NULL;
        }
    }
    
    char* xcaller = NULL, *cli_ip = NULL;
    {
        ngx_list_t* headersin = &(r->headers_in.headers);
        ngx_list_part_t *part = &(headersin->part);
        ngx_table_elt_t * header = part->elts;
        ngx_uint_t i;
        for (i = 0; /* void */; i++) {
            if (i >= part->nelts) {
                if (part->next == NULL) {
                    break;
                }

                part = part->next;
                header = part->elts;
                i = 0;
            }
            if( (header+i)->key.data &&
                    strcasecmp((char*)(header+i)->key.data,"x-caller")==0){
                xcaller = ngx_palloc(r->pool,(header+i)->value.len+1);
                ngx_memcpy(xcaller,(header+i)->value.data,(header+i)->value.len);
                xcaller[(header+i)->value.len] = 0;
                rc = navi_request_set_xcaller(navi_req, xcaller);
                if (rc != NAVI_OK){
                    navi_request_free(navi_req);
                    return NULL;
                }
                break;
            }
        }
    }
    
    if(r->connection->addr_text.len){
        cli_ip = ngx_palloc(r->pool,r->connection->addr_text.len+1);
        ngx_memcpy(cli_ip,r->connection->addr_text.data,r->connection->addr_text.len);
        cli_ip[r->connection->addr_text.len] = 0;
        rc = navi_request_set_cli_ip(navi_req, cli_ip);
        if (rc != NAVI_OK){
            navi_request_free(navi_req);
            return NULL;
        }
    }

    if (r->method == NGX_HTTP_POST){
        rc = ngx_http_navi_process_postbuf(navi_req, r);
        if (rc != NGX_OK){
            navi_request_free(navi_req);
            return NULL;
        }
    }
    
    return navi_req;
}

/*����������Ļص�������
*����http��Ӧ״̬��������navi�Ĵ���
*֮����Ҫ������������
*��ȡ������������Ҫ���������������
*Ϊupstream���ͣ���Ҫ�ٽ���ǰ����upstream���������
*���������������ʱ����ngx_http_navi_main_end_handler
*/
static ngx_int_t ngx_http_navi_sr_end_handler(ngx_http_request_t *r, void *data, ngx_int_t rc)
{
    ngx_int_t ret;
    ngx_int_t status;
    ngx_http_navi_ctx_t* req_ctx;
    navi_request_t* navi;
    ngx_http_request_t *sr;
    navi_request_t* root;

    if (data == NULL){
        return NGX_ERROR;
    }

    req_ctx = (ngx_http_navi_ctx_t *)data;
    if (req_ctx->processed){
        return NGX_OK;
    }
    req_ctx->processed = 1;
    navi = req_ctx->navi_req;
    status = r->headers_out.status;
    if (status == 0){
        navi_http_response_set_status(navi, rc);
    }
    else{
        navi_http_response_set_status(navi, status);
    }
    navi_request_call_process(navi);
    
    root = navi_request_get_root(navi);
    
    void* iter = navi_request_regist_iter(root);
    while((navi = navi_request_regist_iter_next(iter))) {
        ret = ngx_http_navi_add_subrequest(r, navi, 0);
        if (ret == NGX_OK){
            navi_request_set_status(navi, NAVI_REQUEST_DRIVER_PROCESSING);
        }
        else{
            return ret;
        }
    }
    navi_request_regist_iter_destroy(iter);
    
    iter = navi_request_cancel_iter(root);
    while((navi = navi_request_cancel_iter_next(iter))) {
        sr = (ngx_http_request_t*)navi_request_get_driver_peer(navi);
        navi_request_set_status(navi, NAVI_REQUEST_CANCELED);
        if (sr->upstream && sr->upstream->cleanup){
            /*����ngx_http_upstream_cleanup*/
            r->main->count++;
            (*(sr->upstream->cleanup))(sr);
        }
        ngx_http_finalize_request(sr, NGX_HTTP_REQUEST_TIME_OUT);
    }
    navi_request_cancel_iter_destroy(iter);

    if ( NAVI_REQUEST_COMPLETE == navi_request_get_status(root) ) {
        r = ngx_http_navi_get_root_req(root);
        if (r != r->main){
            r->write_event_handler = ngx_http_handler;
            ngx_http_navi_main_end_handler(r);
            return NGX_OK;
        }
        r->write_event_handler = ngx_http_navi_main_end_handler;
    }
    
    return NGX_OK;
}

/*���������ʱ�����������
* ��cnaviģ���ȡ��Ӧ��������
*/
static ngx_int_t ngx_http_navi_main_end_handler_common(ngx_http_request_t* r)
{
    ngx_int_t len = 0;
    ngx_int_t http_status;
    ngx_http_navi_ctx_t* req_ctx = ngx_http_get_module_ctx(r, ngx_http_navi_module);
    navi_request_t* main_req = navi_request_get_root(req_ctx->navi_req);
    char *resp_content = NULL;
    ngx_str_t content_type = ngx_string("text/plain");
    ngx_event_t *ev= (ngx_event_t *)req_ctx->data;
    if (ev != NULL && ev->timer_set) {
        ngx_del_timer(ev);
    }

    void *it = navi_http_response_header_iter(main_req);
    const char* arg, *val;
    ngx_str_t  key, value;
    while ((arg = navi_http_response_header_iter_next(it,&val))) {
        key.len = strlen(arg);
        key.data = (u_char*) ngx_pcalloc(r->pool, key.len);
        ngx_memcpy(key.data, arg, key.len);
        value.len = strlen(val);
        value.data = (u_char*) ngx_pcalloc(r->pool, value.len);
        ngx_memcpy(value.data, val, value.len);

        ngx_http_navi_add_header_out(r, &key, &value);
    }
    navi_http_response_header_iter_destroy(it);

    ngx_chain_t    out;
    ngx_buf_t       *b=NULL;
    http_status = navi_http_response_get_status(main_req);
    len =  navi_http_response_get_body(main_req, (const uint8_t**)&resp_content);    
    if (len > 0){
        b = ngx_create_temp_buf(r->pool, len);
        if (b == NULL){
            return NGX_ERROR;
        }
    	
        ngx_memcpy(b->pos, resp_content, len);
        b->last = b->pos + len;
        b->last_buf = 1;
    }
    
    out.buf = b;
    out.next = NULL;

    navi_request_free(main_req);
    req_ctx = NULL;
    ngx_http_set_ctx(r, req_ctx, ngx_http_navi_module);

     //�����Ӧ
    ngx_http_navi_respond_header(r,&content_type,len,http_status,NULL);
    if (len > 0){	
        return ngx_http_output_filter(r, &out);
    }
    else{
        return ngx_http_output_filter(r, NULL);
    }
}

/*���������ʱ�����մ���
*ngx_http_navi_main_end_handler_common��û��������ĵ���
*/
static void ngx_http_navi_main_end_handler(ngx_http_request_t* r)
{
    ngx_int_t rc = NGX_OK;
   
    rc = ngx_http_navi_main_end_handler_common(r);
    ngx_http_send_special(r,NGX_HTTP_LAST);
    r->count=1;
    ngx_http_finalize_request(r, rc);
}

/*����������*/
static ngx_int_t ngx_http_navi_add_subrequest(ngx_http_request_t *r, navi_request_t *sub, ngx_uint_t flags)
{
    ngx_time_t                    *tp;
    ngx_connection_t              *c;
    ngx_http_request_t            *sr;
    ngx_http_post_subrequest_t *ps;
    ngx_str_t* uri_query;
    ngx_http_core_srv_conf_t      *cscf;
    ngx_http_navi_ctx_t *ctx;
  
    sr = ngx_pcalloc(r->pool, sizeof(ngx_http_request_t));
    if (sr == NULL) {
        return NGX_ERROR;
    }

    sr->signature = NGX_HTTP_MODULE;

    c = r->connection;
    sr->connection = c;
    sr->pool = r->pool;
	
    sr->ctx = ngx_pcalloc(sr->pool, sizeof(void *) * ngx_http_max_module);
    if (sr->ctx == NULL) {
        return NGX_ERROR;
    }

    if (ngx_list_init(&sr->headers_in.headers, sr->pool, 20,
                      sizeof(ngx_table_elt_t))
        != NGX_OK)
    {
        return NGX_ERROR;
    }
	
    if (ngx_list_init(&sr->headers_out.headers, sr->pool, 20,
                      sizeof(ngx_table_elt_t))
        != NGX_OK)
    {
        return NGX_ERROR;
    }

    cscf = ngx_http_get_module_srv_conf(r, ngx_http_core_module);
    sr->main_conf = cscf->ctx->main_conf;
    sr->srv_conf = cscf->ctx->srv_conf;
    sr->loc_conf = cscf->ctx->loc_conf;

    ngx_http_clear_content_length(sr);
    ngx_http_clear_accept_ranges(sr);
    ngx_http_clear_last_modified(sr);

    sr->method = NGX_HTTP_GET;
    sr->http_version = r->http_version;

    sr->request_line = r->request_line;
    ngx_int_t uri_len = navi_http_request_get_uri_query(sub,  NULL, 0);	
    uri_query = ngx_palloc(sr->pool, sizeof(*uri_query)+uri_len+1);
    uri_query->data = (u_char*)(uri_query+1);
    uri_query->len = uri_len+1;
    uri_query->len =  navi_http_request_get_uri_query(sub,  (char *)(uri_query->data), uri_query->len);	
    sr->uri = *uri_query;
    sr->uri_end = sr->uri.data + sr->uri.len;
    u_char *p = (u_char *)strstr((char *)(sr->uri.data), "?") ;
    if (p != NULL){
        sr->args_start = ++p;    
        sr->args.len = sr->uri_end  - sr->args_start;
        sr->args.data = sr->args_start;
        sr->args_start = NULL;
        sr->uri.len -= (sr->args.len+1);
    }
    u_char *dst, *src;
    dst=src= sr->uri.data;
    ngx_unescape_uri(&dst, &src, sr->uri.len, NGX_UNESCAPE_URI);
    *dst='\0';
    sr->uri.len = dst -sr->uri.data;
    sr->uri_end = dst;
	
    ngx_log_debug(NGX_LOG_DEBUG_HTTP, c->log, 0,
                   "http subrequest \"%V\"", uri_query);

    sr->subrequest_in_memory = (flags & NGX_HTTP_SUBREQUEST_IN_MEMORY) != 0;
    sr->waited = (flags & NGX_HTTP_SUBREQUEST_WAITED) != 0;

    sr->unparsed_uri = r->unparsed_uri;
    sr->method_name = ngx_http_core_get_method;
    sr->http_protocol = r->http_protocol;

    void *it = navi_http_request_header_iter(sub);
    const char* arg, *val;
    ngx_str_t  key, value;
    while ((arg = navi_http_request_header_iter_next(it,&val))) {
        key.len = strlen(arg);
        key.data = (u_char*) ngx_pcalloc(sr->pool, key.len);
        ngx_memcpy(key.data, arg, key.len);
        value.len = strlen(val);
        value.data = (u_char*) ngx_pcalloc(sr->pool, value.len);
        ngx_memcpy(value.data, val, value.len);
        ngx_http_navi_add_header_in(sr, &key, &value);
    }
    navi_http_request_header_iter_destroy(it);

    const u_char *post_content;
    ngx_int_t post_len;
    post_len = navi_http_request_get_post(sub, &post_content);

    if (post_len > 0){
        ngx_http_navi_set_post(sr, post_content, post_len);
    }
    ngx_http_set_exten(sr);

    ctx = ngx_pcalloc(sr->pool, sizeof(ngx_http_navi_ctx_t) );
    if (sr->ctx == NULL) {
        return NGX_ERROR;
    }
    ctx->navi_req = sub;
    navi_request_set_driver_peer(sub, sr);
    ngx_http_set_ctx(sr, ctx, ngx_http_navi_module);

    ps = ngx_pnalloc(sr->pool, sizeof(ngx_http_post_subrequest_t));
    ps->handler = ngx_http_navi_sr_end_handler;
    ps->data = ctx;

    sr->main = r->main;
    sr->parent = r->main;
    sr->post_subrequest = ps;
    sr->read_event_handler = ngx_http_request_empty_handler;
    sr->write_event_handler = ngx_http_handler;

    ngx_http_core_main_conf_t  *cmcf = ngx_http_get_module_main_conf(r->main, ngx_http_core_module);
    sr->variables = ngx_pcalloc(sr->pool, cmcf->variables.nelts * sizeof(ngx_http_variable_value_t));

    sr->log_handler = r->log_handler;

    sr->internal = 1;

    sr->discard_body = r->discard_body;
    sr->expect_tested = 1;
    sr->main_filter_need_in_memory = r->main_filter_need_in_memory;

    sr->uri_changes = NGX_HTTP_MAX_URI_CHANGES + 1;

    tp = ngx_timeofday();
    sr->start_sec = tp->sec;
    sr->start_msec = tp->msec;

    r->main->count++;

    return ngx_http_post_request(sr, NULL);
}

/*������ʱ��������
*�����д���nginx�������̵�������ȡ����
*������������������Ϊupstream����
*��Ҫ�ڽ���������֮ǰ���upstream
*/
static void ngx_http_navi_main_timeout(ngx_event_t* ev) {
    if (ev->timedout) {
        ngx_http_request_t* r = (ngx_http_request_t*)ev->data;
        ngx_http_request_t* sr;
        ngx_http_navi_ctx_t* req_ctx;
        navi_request_t* root;
        navi_request_t* navi;

        req_ctx = ngx_http_get_module_ctx(r, ngx_http_navi_module);
        if (req_ctx == NULL){
            return;
        }
        root = navi_request_get_root(req_ctx->navi_req);
        navi_request_set_process(root, NULL);
        navi_request_abort_root(root, "timeout");
        navi_http_response_set_status(root, NGX_HTTP_REQUEST_TIME_OUT);
        void  *iter = navi_request_cancel_iter(root);
        while((navi = navi_request_cancel_iter_next(iter))) {
            sr = (ngx_http_request_t*)navi_request_get_driver_peer(navi);
            navi_request_set_status(navi, NAVI_REQUEST_CANCELED);
            if (sr->upstream && sr->upstream->cleanup){
                /*����ngx_http_upstream_cleanup*/
                r->main->count++;
                (*(sr->upstream->cleanup))(sr);
            }
            ngx_http_finalize_request(sr, NGX_HTTP_REQUEST_TIME_OUT);
        }
        navi_request_cancel_iter_destroy(iter);
	
        ngx_http_navi_main_end_handler(r);
    }
}

/*���������*/
static ngx_int_t ngx_http_navi_process_request(ngx_http_request_t* r)
{
    navi_request_t *navi_req = ngx_http_navi_build_request(r);
    if (navi_req == NULL){
        ngx_http_finalize_request(r, NGX_HTTP_INTERNAL_SERVER_ERROR);
        return NGX_OK;
    }
    ngx_int_t rc;
    navi_request_t* sub;
    void* iter_sub;
    ngx_http_navi_ctx_t *ctx;
	
    rc = navi_mgr_run_request(navi_module_mgr, navi_req);
    if (rc != NAVI_OK){
        navi_request_free(navi_req);
        ngx_http_finalize_request(r, NGX_HTTP_INTERNAL_SERVER_ERROR);
        return NGX_OK;
    }

    ctx = ngx_pcalloc(r->pool, sizeof(ngx_http_navi_ctx_t));
    ctx->navi_req = navi_req;
    navi_request_set_driver_peer(navi_req, r);
    ngx_http_set_ctx(r, ctx, ngx_http_navi_module);
    
    iter_sub= navi_request_regist_iter(navi_req);
    while((sub = navi_request_regist_iter_next(iter_sub))) {
        rc = ngx_http_navi_add_subrequest(r, sub, 0);
        if (rc == NGX_OK){
            navi_request_set_status(sub, NAVI_REQUEST_DRIVER_PROCESSING);
        }
        else{
             navi_request_free(navi_req);
	      ngx_http_send_special(r,NGX_HTTP_LAST);
             r->main->count=1;
             ngx_http_finalize_request(r, NGX_HTTP_INTERNAL_SERVER_ERROR);
             return NGX_OK;	
        }
    }
    navi_request_regist_iter_destroy(iter_sub);
    ngx_http_navi_timer_process(r);

    ngx_int_t timeout = navi_request_timeout(navi_req);
    if (timeout != 0 && r == r->main){
        ngx_event_t *ev = ngx_pcalloc(r->pool, sizeof(ngx_event_t));
        ev->handler  = ngx_http_navi_main_timeout;
        ev->data = r;
        ctx->data = ev;
        ngx_add_timer(ev, timeout);
    }

    if (NAVI_REQUEST_COMPLETE == navi_request_get_status(navi_req)) {
        //�����Ӧ
        return ngx_http_navi_main_end_handler_common(r);
    }

    return NGX_DONE;
}

/*ģ���ⳬʱ��������
*���naviģ��Ŀ¼������ģ��
*����ģ�鶨ʱ��������
*�����Ҫ�ٴ����Ӷ�ʱ��
*ע�⣬����ngx_exiting״̬ʱ���������Ӷ�ʱ��
*/
static void ngx_http_navi_module_check(ngx_event_t *ev) 
{
    if (ev->timedout){ 
        navi_mgr_check_modules(navi_module_mgr);
        ngx_http_navi_timer_process();

        if (!ngx_exiting) {
            ngx_add_timer(ev,  (ngx_msec_t)(ev->data)*1000);
        }
    }
}

/*ģ�鶨ʱ����ʱ��������,
*��Ҫ��������zombie״̬�Ķ�ʱ��,
*���ó�ʱ�����ص�,
*��������ڶ�ʱ��������Ҫ�ٴμ���ngx_event_timer_rbtree,
*ע�⣬����ngx_exiting״̬ʱ���������Ӷ�ʱ��
*/
static void ngx_http_navi_timer_handler(ngx_event_t *ev) 
{
    if (ev->timedout) {
        navi_timer_t *ptimer = (navi_timer_t *)(ev->data);
        if (ptimer == NULL){
            return;
        }
        if (navi_timer_is_zombie(ptimer)){
            navi_timer_cleanup(ptimer);
            ev->data = NULL;
            return;
        }
    
        navi_timer_timeout(ptimer);
        if (navi_timer_is_zombie(ptimer)){
            navi_timer_cleanup(ptimer);
            ev->data = NULL;
            return;
        }
        if (ptimer->type == NAVI_TIMER_INTERVAL &&  !ngx_exiting) {
            ngx_add_timer(ev,  ptimer->to_ms);
        }
    }
}

/*����ģ�鶨ʱ��������ע��Ķ�ʱ������ngx_event_timer_rbtree��
* ��ȡ���Ķ�ʱ����ngx_event_timer_rbtree���Ƴ�
*/
static void  ngx_http_navi_timer_process( )
{
    void *iter;
    navi_timer_t *ptimer;
    iter = navi_timer_iter(&(navi_module_mgr->timer_mgr), NAVI_TIMER_REGISTED);
    while((ptimer = navi_timer_iter_next(iter))){
        ngx_event_t *ev = ngx_pcalloc(pcycle->pool, sizeof(ngx_event_t));
        ev->handler  = ngx_http_navi_timer_handler;
        ev->data = ptimer; 
        navi_timer_running(ptimer, ev);
        ngx_add_timer(ev, ptimer->to_ms);
    }
    navi_timer_iter_destroy(iter);

    iter = navi_timer_iter(&(navi_module_mgr->timer_mgr), NAVI_TIMER_CANCEL);
    while((ptimer = navi_timer_iter_next(iter))){
        ngx_event_del_timer((ngx_event_t*)(ptimer->driver_peer));
        navi_timer_canceled(ptimer);
    }
    navi_timer_iter_destroy(iter);
}

/*content handler*/
static ngx_int_t ngx_http_navi_init_handler(ngx_http_request_t* r)
{
    ngx_http_navi_main_conf_t* mcf = ngx_http_get_module_main_conf(r, ngx_http_navi_module);
    ngx_int_t rc = NGX_OK;
    
    if (navi_module_mgr == NULL){
        if (mcf->navi_directory.len == 0){
            navi_module_mgr = navi_mgr_init(NULL);
        }
        else{
            navi_module_mgr = navi_mgr_init((const char *)(mcf->navi_directory.data));
        }
        
        if (navi_module_mgr == NULL){
            return NGX_ERROR;
        }
    }
    
    if (ev_check_time == NULL && mcf->check_interval > 0){
        ev_check_time = ngx_pcalloc(pcycle->pool,sizeof(ngx_event_t));
        ev_check_time->handler = ngx_http_navi_module_check;
        ev_check_time->data = (void *)(mcf->check_interval);
        ngx_add_timer(ev_check_time, (mcf->check_interval)*1000);
    }
    
    if(r->method == NGX_HTTP_GET){
        rc = ngx_http_navi_process_request(r);
        return rc;
    }
    else if(r->method == NGX_HTTP_HEAD){
        ngx_http_send_header(r);
        return ngx_http_output_filter(r, NULL);
    }
    else if(r->method == NGX_HTTP_POST){
        /* body�ڴ���ڵ���buf���ļ��� */
        r->request_body_in_single_buf = 1;
        r->request_body_in_persistent_file = 0;
        r->request_body_in_clean_file = 0;
        r->request_body_file_log_level = 0;
        
        rc = ngx_http_read_client_request_body(r, ngx_http_navi_body_handler);
        return NGX_OK;
    }
    ngx_http_navi_add_header_out(r, &NGX_HTTP_NAVI_HEADER_ALLOW, &NGX_HTTP_NAVI_ALLOW_METHOD);
    return NGX_HTTP_NOT_ALLOWED;
}

static ngx_int_t ngx_http_navi_set_header_in_util(ngx_http_request_t *r, 
	ngx_http_navi_header_val_t *hv, ngx_str_t *value, ngx_table_elt_t **out)
{
    ngx_table_elt_t  *h, **old;

    if (hv->offset) {
        old = (ngx_table_elt_t **) ((char *) &r->headers_in + hv->offset);
    } else {
        old = NULL;	
    }

    if (old == NULL || *old == NULL) {
        h =  ngx_list_push(&r->headers_in.headers);
        old = &h;
    }
    else{
        h= *old;
    }

    if (value->len == 0) {
        h->hash = 0;
    }
    else{
        h->hash = hv->hash;
    }

    h->hash = hv->hash;
    h->key = hv->key;
    h->value = *value;
    h->lowcase_key = ngx_pnalloc(r->pool, h->key.len);
    if (h->lowcase_key == NULL) {
        return NGX_ERROR;
    }

    ngx_strlow(h->lowcase_key, h->key.data, h->key.len);

    if (out) {
        *out = h;
    }

    return NGX_OK;
}

static ngx_int_t ngx_http_navi_set_header_in(ngx_http_request_t *r, 
	ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    return ngx_http_navi_set_header_in_util(r, hv, value, NULL);
}
	
static ngx_int_t ngx_http_navi_set_connection_header_in(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    r->headers_in.connection_type = 0;

    if (value->len == 0) {
        return ngx_http_navi_set_header_in(r, hv, value);
    }

    if (ngx_strcasestrn(value->data, "close", 5 - 1)) {
        r->headers_in.connection_type = NGX_HTTP_CONNECTION_CLOSE;
        r->headers_in.keep_alive_n = -1;

    } else if (ngx_strcasestrn(value->data, "keep-alive", 10 - 1)) {
        r->headers_in.connection_type = NGX_HTTP_CONNECTION_KEEP_ALIVE;
    }

    return ngx_http_navi_set_header_in(r, hv, value);
}

static ngx_int_t ngx_http_navi_set_host_header_in(ngx_http_request_t *r, 
	ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    r->headers_in.server = *value;

    return ngx_http_navi_set_header_in(r, hv, value);
}

static ngx_int_t ngx_http_navi_set_user_agent_header_in(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    u_char  *user_agent, *msie;

    /* clear existing settings */

    r->headers_in.msie = 0;
    r->headers_in.msie6 = 0;
    r->headers_in.opera = 0;
    r->headers_in.gecko = 0;
    r->headers_in.chrome = 0;
    r->headers_in.safari = 0;
    r->headers_in.konqueror = 0;

    if (value->len == 0) {
        return ngx_http_navi_set_header_in(r, hv, value);
    }

    /* check some widespread browsers */

    user_agent = value->data;

    msie = ngx_strstrn(user_agent, "MSIE ", 5 - 1);

    if (msie && msie + 7 < user_agent + value->len) {

        r->headers_in.msie = 1;

        if (msie[6] == '.') {

            switch (msie[5]) {
            case '4':
            case '5':
                r->headers_in.msie6 = 1;
                break;
            case '6':
                if (ngx_strstrn(msie + 8, "SV1", 3 - 1) == NULL) {
                    r->headers_in.msie6 = 1;
                }
                break;
            }
        }
    }

    if (ngx_strstrn(user_agent, "Opera", 5 - 1)) {
        r->headers_in.opera = 1;
        r->headers_in.msie = 0;
        r->headers_in.msie6 = 0;
    }

    if (!r->headers_in.msie && !r->headers_in.opera) {

        if (ngx_strstrn(user_agent, "Gecko/", 6 - 1)) {
            r->headers_in.gecko = 1;

        } else if (ngx_strstrn(user_agent, "Chrome/", 7 - 1)) {
            r->headers_in.chrome = 1;

        } else if (ngx_strstrn(user_agent, "Safari/", 7 - 1)
                   && ngx_strstrn(user_agent, "Mac OS X", 8 - 1))
        {
            r->headers_in.safari = 1;

        } else if (ngx_strstrn(user_agent, "Konqueror", 9 - 1)) {
            r->headers_in.konqueror = 1;
        }
    }

    return ngx_http_navi_set_header_in(r, hv, value);
}

static ngx_int_t
ngx_http_navi_set_content_length_header_in(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    off_t           len;

    if (value->len == 0) {
        r->headers_in.content_length_n = -1;
        return ngx_http_navi_set_header_in(r, hv, value);
    }

    len = ngx_atosz(value->data, value->len);
    if (len == NGX_ERROR) {
        return NGX_ERROR;
    }

    r->headers_in.content_length_n = len;

    return ngx_http_navi_set_header_in(r, hv, value);
}

static ngx_int_t ngx_http_navi_set_cookie_header(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    ngx_table_elt_t  **cookie, *h;

    if (r->headers_in.cookies.nalloc == 0) {
        if (ngx_array_init(&r->headers_in.cookies, r->pool, 2, sizeof(ngx_table_elt_t *))
            != NGX_OK)
        {
            return NGX_ERROR;
        }
    }

    if (ngx_http_navi_set_header_in_util(r, hv, value, &h) == NGX_ERROR) {
        return NGX_ERROR;
    }

    if (value->len == 0) {
        return NGX_OK;
    }

    cookie = ngx_array_push(&r->headers_in.cookies);
    if (cookie == NULL) {
        return NGX_ERROR;
    }

    *cookie = h;
    return NGX_OK;
}

static ngx_http_navi_set_header_t  ngx_http_navi_set_handlers_heads_in[] = {

#if (NGX_HTTP_GZIP)
    { ngx_string("Accept-Encoding"),
                 offsetof(ngx_http_headers_in_t, accept_encoding),
                 ngx_http_navi_set_header_in },

    { ngx_string("Via"),
                 offsetof(ngx_http_headers_in_t, via),
                 ngx_http_navi_set_header_in },
#endif

    { ngx_string("Host"),
                 offsetof(ngx_http_headers_in_t, host),
                 ngx_http_navi_set_host_header_in },

    { ngx_string("Connection"),
                 offsetof(ngx_http_headers_in_t, connection),
                 ngx_http_navi_set_connection_header_in },

    { ngx_string("If-Modified-Since"),
                 offsetof(ngx_http_headers_in_t, if_modified_since),
                 ngx_http_navi_set_header_in },

    { ngx_string("User-Agent"),
                 offsetof(ngx_http_headers_in_t, user_agent),
                 ngx_http_navi_set_user_agent_header_in },

    { ngx_string("Referer"),
                 offsetof(ngx_http_headers_in_t, referer),
                 ngx_http_navi_set_header_in },

    { ngx_string("Content-Type"),
                 offsetof(ngx_http_headers_in_t, content_type),
                 ngx_http_navi_set_header_in },

    { ngx_string("Range"),
                 offsetof(ngx_http_headers_in_t, range),
                 ngx_http_navi_set_header_in },

    { ngx_string("If-Range"),
                 offsetof(ngx_http_headers_in_t, if_range),
                 ngx_http_navi_set_header_in },

    { ngx_string("Transfer-Encoding"),
                 offsetof(ngx_http_headers_in_t, transfer_encoding),
                 ngx_http_navi_set_header_in },

    { ngx_string("Expect"),
                 offsetof(ngx_http_headers_in_t, expect),
                 ngx_http_navi_set_header_in },

    { ngx_string("Authorization"),
                 offsetof(ngx_http_headers_in_t, authorization),
                 ngx_http_navi_set_header_in },

    { ngx_string("Keep-Alive"),
                 offsetof(ngx_http_headers_in_t, keep_alive),
                 ngx_http_navi_set_header_in },

    { ngx_string("Content-Length"),
                 offsetof(ngx_http_headers_in_t, content_length),
                 ngx_http_navi_set_content_length_header_in },

    { ngx_string("Cookie"),
                 0,
                 ngx_http_navi_set_cookie_header },

#if (NGX_HTTP_REALIP)
    { ngx_string("X-Real-IP"),
                 offsetof(ngx_http_headers_in_t, x_real_ip),
                 ngx_http_navi_set_header_in },
#endif

    { ngx_null_string, 0, ngx_http_navi_set_header_in }
};

/*����header in ͷ��*/
static  ngx_int_t ngx_http_navi_add_header_in(ngx_http_request_t* r, 
	const ngx_str_t* key, const ngx_str_t* value) 
{
    ngx_http_navi_header_val_t         hv;
    ngx_http_navi_set_header_t        *handlers = ngx_http_navi_set_handlers_heads_in;
    ngx_uint_t                        i;

    hv.hash = ngx_hash_key_lc(key->data, key->len);
    hv.key = *key;

    hv.offset = 0;    
    hv.handler = NULL;

    for (i = 0; handlers[i].name.len; i++) {
        if (hv.key.len != handlers[i].name.len
            || ngx_strncasecmp(hv.key.data, handlers[i].name.data,
                               handlers[i].name.len) != 0)
        {
            continue;
        }
        hv.offset = handlers[i].offset;
        hv.handler = handlers[i].handler;
        break;
    }

    if (handlers[i].name.len == 0 && handlers[i].handler) {
        hv.offset = handlers[i].offset;
        hv.handler = handlers[i].handler;
    }

    if (hv.handler == NULL) {
        return NGX_ERROR;
    }

    return hv.handler(r, &hv, (ngx_str_t *)value); 
}

static ngx_int_t ngx_http_navi_set_header_out(ngx_http_request_t *r, 
	ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    ngx_table_elt_t  *h, **old;

    if (hv->offset) {
        old = (ngx_table_elt_t **) ((char *) &r->headers_out + hv->offset);
    } else {
        old = NULL;	
    }

    if (old == NULL || *old == NULL) {
        h =  ngx_list_push(&r->headers_out.headers);
        old = &h;
    }
    else{
        h= *old;
    }

    if (value->len == 0) {
        h->hash = 0;
    }
    else{
        h->hash = hv->hash;
    }

    h->hash = hv->hash;
    h->key = hv->key;
    h->value = *value;
    h->lowcase_key = ngx_pnalloc(r->pool, h->key.len);
    if (h->lowcase_key == NULL) {
        return NGX_ERROR;
    }

    ngx_strlow(h->lowcase_key, h->key.data, h->key.len);
	
    return NGX_OK;
}

static ngx_int_t ngx_http_navi_set_last_modified_header_out(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    r->headers_out.last_modified_time = ngx_http_parse_time(value->data,
                                                            value->len);

    return ngx_http_navi_set_header_out(r, hv, value);
}

static ngx_int_t
ngx_http_navi_set_content_length_header_out(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    off_t           len;

    len = ngx_atosz(value->data, value->len);
    if (len == NGX_ERROR) {
        return NGX_ERROR;
    }

    r->headers_out.content_length_n = len;

    return NGX_OK;
}

static ngx_int_t
ngx_http_navi_set_content_type_header_out(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    r->headers_out.content_type_len = value->len;
    r->headers_out.content_type = *value;
    r->headers_out.content_type_hash = hv->hash;
    r->headers_out.content_type_lowcase = NULL;

    return NGX_OK;
}

static ngx_int_t
ngx_http_navi_set_cache_control_header_out(ngx_http_request_t *r,
    ngx_http_navi_header_val_t *hv, ngx_str_t *value)
{
    ngx_array_t      *pa;
    ngx_table_elt_t  *ho, **ph;

    pa = (ngx_array_t *) ((char *) &r->headers_out + hv->offset);

    if (pa->elts == NULL) {
        if (ngx_array_init(pa, r->pool, 2, sizeof(ngx_table_elt_t *))
            != NGX_OK)
        {
            return NGX_ERROR;
        }
    }

    ph = ngx_array_push(pa);
    if (ph == NULL) {
        return NGX_ERROR;
    }

    ho = ngx_list_push(&r->headers_out.headers);
    if (ho == NULL) {
        return NGX_ERROR;
    }

    ho->value = *value;
    ho->hash = hv->hash;
    ngx_str_set(&ho->key, "Cache-Control");
    *ph = ho;

    return NGX_OK;
}

static ngx_http_navi_set_header_t  ngx_http_navi_set_handlers_heads_out[] = {

    { ngx_string("Server"),
                 offsetof(ngx_http_headers_out_t, server),
                 ngx_http_navi_set_header_out },

    { ngx_string("Date"),
                 offsetof(ngx_http_headers_out_t, date),
                 ngx_http_navi_set_header_out },

    { ngx_string("Content-Encoding"),
                 offsetof(ngx_http_headers_out_t, content_encoding),
                 ngx_http_navi_set_header_out },

    { ngx_string("Location"),
                 offsetof(ngx_http_headers_out_t, location),
                 ngx_http_navi_set_header_out },

    { ngx_string("Refresh"),
                 offsetof(ngx_http_headers_out_t, refresh),
                 ngx_http_navi_set_header_out },

    { ngx_string("Last-Modified"),
                 offsetof(ngx_http_headers_out_t, last_modified),
                 ngx_http_navi_set_last_modified_header_out },

    { ngx_string("Content-Range"),
                 offsetof(ngx_http_headers_out_t, content_range),
                 ngx_http_navi_set_header_out },

    { ngx_string("Accept-Ranges"),
                 offsetof(ngx_http_headers_out_t, accept_ranges),
                 ngx_http_navi_set_header_out },

    { ngx_string("WWW-Authenticate"),
                 offsetof(ngx_http_headers_out_t, www_authenticate),
                 ngx_http_navi_set_header_out },

    { ngx_string("Expires"),
                 offsetof(ngx_http_headers_out_t, expires),
                 ngx_http_navi_set_header_out },

    { ngx_string("E-Tag"),
                 offsetof(ngx_http_headers_out_t, etag),
                 ngx_http_navi_set_header_out },

    { ngx_string("ETag"),
                 offsetof(ngx_http_headers_out_t, etag),
                 ngx_http_navi_set_header_out },

    { ngx_string("Content-Length"),
                 offsetof(ngx_http_headers_out_t, content_length),
                 ngx_http_navi_set_content_length_header_out },

    { ngx_string("Content-Type"),
                 offsetof(ngx_http_headers_out_t, content_type),
                 ngx_http_navi_set_content_type_header_out },

    { ngx_string("Cache-Control"),
                 offsetof(ngx_http_headers_out_t, cache_control),
                 ngx_http_navi_set_cache_control_header_out },

    { ngx_null_string, 0, ngx_http_navi_set_header_out }
};

/*����header out ͷ��*/
static  ngx_int_t ngx_http_navi_add_header_out(ngx_http_request_t* r, 
	const ngx_str_t* key, const ngx_str_t* value) 
{
    ngx_http_navi_header_val_t         hv;
    ngx_http_navi_set_header_t        *handlers = ngx_http_navi_set_handlers_heads_out;
    ngx_uint_t                        i;

    hv.hash = ngx_hash_key_lc(key->data, key->len);
    hv.key = *key;

    hv.offset = 0;    
    hv.handler = NULL;

    for (i = 0; handlers[i].name.len; i++) {
        if (hv.key.len != handlers[i].name.len
            || ngx_strncasecmp(hv.key.data, handlers[i].name.data,
                               handlers[i].name.len) != 0)
        {
            continue;
        }
        hv.offset = handlers[i].offset;
        hv.handler = handlers[i].handler;
        break;
    }

    if (handlers[i].name.len == 0 && handlers[i].handler) {
        hv.offset = handlers[i].offset;
        hv.handler = handlers[i].handler;
    }

    if (hv.handler == NULL) {
        return NGX_ERROR;
    }

    return hv.handler(r, &hv, (ngx_str_t *)value); 
}

/*���������Ӧͷ*/
static ngx_int_t ngx_http_navi_respond_header(ngx_http_request_t *r, ngx_str_t* content_type, 
        ngx_int_t content_len, ngx_int_t status_code, const ngx_str_t *status_line)
{
    if(content_type != NULL){
        r->headers_out.content_type.len=content_type->len;
        r->headers_out.content_type.data = content_type->data;
        r->headers_out.content_type_len = r->headers_out.content_type.len;
    }
    if(content_len > 0){
        r->headers_out.content_length_n = content_len;
    }
    else{
        r->headers_out.content_length_n = 0;
        r->header_only = 1;
    }
    r->headers_out.status = status_code;
    if(status_line != NULL){
        r->headers_out.status_line.len = status_line->len;
        r->headers_out.status_line.data = status_line->data;
    }
    return ngx_http_send_header(r);
}

